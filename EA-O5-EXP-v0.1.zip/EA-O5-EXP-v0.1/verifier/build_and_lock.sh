#!/usr/bin/env bash
# EA-O5-EXP-v0.1: build the DPoP verifier, check the build is reproducible, and write
#   dependencies.lock   sha256 of every runtime jar packed into the verifier jar (BOOT-INF/lib)
#   dist/eao5-dpop-verifier.jar   the jar that is deposited and deployed
#   BUILD_RECORD.json   source-tree hash, jar hash, lock hash, toolchain
# Run on a machine with Maven Central access, before deposit. analysis.py refuses to freeze
# without BUILD_RECORD.json, and voids the study if the conformance block's verifier hashes differ.
set -euo pipefail
cd "$(dirname "$0")"

JAR=target/eao5-dpop-verifier.jar
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

# Source tree hash: sha256 of the sha256sum listing of pom.xml and every file under src/,
# paths relative to verifier/, sorted bytewise. analysis.py computes the same value.
source_tree_sha256() {
  find pom.xml src -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum | sha256sum | cut -d' ' -f1
}

# 1. Build with tests (the service-level CT1-CT7 suite must pass).
mvn -B -ntp clean verify
cp "$JAR" "$TMP/first.jar"

# 2. Rebuild from clean; the jar must be byte-identical (project.build.outputTimestamp is fixed).
mvn -B -ntp -q clean package -DskipTests
if ! cmp -s "$JAR" "$TMP/first.jar"; then
  echo "verifier jar is not reproducible: two clean builds differ" >&2
  exit 1
fi

# 3. Dependency lock: every runtime library inside the jar, with its hash.
: > dependencies.lock
while IFS= read -r entry; do
  h=$(unzip -p "$JAR" "$entry" | sha256sum | cut -d' ' -f1)
  printf '%s  %s\n' "$h" "${entry#BOOT-INF/lib/}" >> dependencies.lock
done < <(unzip -Z1 "$JAR" | grep '^BOOT-INF/lib/.*\.jar$' | LC_ALL=C sort)

# 4. Deposit copy of the jar.
mkdir -p dist
cp "$JAR" dist/eao5-dpop-verifier.jar

# 5. Build record.
SRC=$(source_tree_sha256)
JARH=$(sha256sum "$JAR" | cut -d' ' -f1)
LOCKH=$(sha256sum dependencies.lock | cut -d' ' -f1)
# Toolchain strings are JSON-escaped: `java -version` prints the version in double quotes.
json_escape() { sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }
MVN=$(mvn -v | head -1 | json_escape)
JAVA=$(java -version 2>&1 | head -1 | json_escape)
cat > BUILD_RECORD.json <<JSON
{
  "verifier_source_tree_sha256": "$SRC",
  "verifier_jar_sha256": "$JARH",
  "verifier_build_lockfile_sha256": "$LOCKH",
  "jar": "verifier/dist/eao5-dpop-verifier.jar",
  "maven": "$MVN",
  "java": "$JAVA",
  "reproducible": true
}
JSON
# The record must parse as JSON before anything else relies on it.
python3 -c 'import json,sys; json.load(open("BUILD_RECORD.json")); print("BUILD_RECORD.json is valid JSON")'
echo "BUILD_RECORD.json written: jar $JARH"
