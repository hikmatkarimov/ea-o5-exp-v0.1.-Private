#!/usr/bin/env bash
# Rebuilds CONTRACT.pdf from contract.md (exported from the EA-O5 Experimental Contract v0.1 document).
# Toolchain used for the deposited PDF: pandoc 3.1.3, KaTeX 0.16.47 (npm), Playwright Chromium, DejaVu fonts.
# The text is the source of record; the PDF bytes depend on the toolchain and are not expected to be
# bit-identical on another machine.
set -euo pipefail
cd "$(dirname "$0")"
[ -d node_modules/katex ] || npm install --no-save katex@0.16.47
pandoc contract.md -f gfm+tex_math_dollars -t html5 --standalone --wrap=none --katex \
  --lua-filter=math.lua --css=style.css --metadata title="EA-O5 Experimental Contract v0.1" -o contract_katex.html
node render.js
python3 - <<'PY'
from playwright.sync_api import sync_playwright
import pathlib
p = pathlib.Path("contract_final.html").resolve()
with sync_playwright() as pw:
    b = pw.chromium.launch(); pg = b.new_page()
    pg.goto(p.as_uri()); pg.wait_for_load_state("networkidle"); pg.evaluate("document.fonts.ready")
    pg.pdf(path="../CONTRACT.pdf", format="A4", print_background=True, prefer_css_page_size=True,
           display_header_footer=True, header_template="<span></span>",
           footer_template='<div style="font:8px DejaVu Sans,sans-serif;color:#666;width:100%;text-align:center">EA-O5 Experimental Contract v0.1 &middot; <span class="pageNumber"></span> / <span class="totalPages"></span></div>',
           margin={"top": "20mm", "bottom": "20mm", "left": "18mm", "right": "18mm"})
    b.close()
PY
rm -f contract_katex.html contract_final.html
echo "CONTRACT.pdf rebuilt"
