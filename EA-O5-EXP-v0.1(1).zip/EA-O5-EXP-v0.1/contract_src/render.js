const fs = require('fs'); const katex = require('katex'); const path = require('path');
let html = fs.readFileSync('contract_katex.html', 'utf8');
// drop pandoc's CDN KaTeX loader
html = html.replace(/<script[^>]*?katex[\s\S]*?<\/script>/g, '').replace(/<script>[\s\S]*?renderMathInElement[\s\S]*?<\/script>/g, '')
           .replace(/<link[^>]*katex[^>]*>/g, '');
const dec = s => s.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&');
let n = 0;
html = html.replace(/<span\s+class="math (display|inline)">([\s\S]*?)<\/span>/g, (m, mode, tex) => {
  n++; return katex.renderToString(dec(tex), {displayMode: mode === 'display', throwOnError: true, output: 'html'});
});
const css = path.resolve('node_modules/katex/dist/katex.min.css');
html = html.replace('</head>', `<link rel="stylesheet" href="file://${css}">\n</head>`);
fs.writeFileSync('contract_final.html', html);
console.log('rendered', n);
