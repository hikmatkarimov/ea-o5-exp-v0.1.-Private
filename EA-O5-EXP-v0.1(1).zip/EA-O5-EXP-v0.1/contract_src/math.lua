-- ```latex blocks -> display math; formulas joined by \qquad become stacked rows.
function CodeBlock(el)
  if el.classes[1] == "latex" then
    local tex = el.text
    if tex:find("\\qquad") then
      local rows = {}
      for part in (tex .. "\\qquad"):gmatch("(.-)\\qquad") do
        part = part:gsub("^%s+", ""):gsub("%s+$", ""):gsub(",$", "")
        if #part > 0 then table.insert(rows, part) end
      end
      tex = "\\begin{array}{l}" .. table.concat(rows, " \\\\ ") .. "\\end{array}"
    end
    return pandoc.Para({pandoc.Math("DisplayMath", tex)})
  end
end

-- Task-list boxes as visible symbols (disabled inputs do not print reliably).
function Str(el)
  if el.text == "☒" then return pandoc.RawInline("html", '<span class="box done">☑</span>') end
  if el.text == "☐" then return pandoc.RawInline("html", '<span class="box open">☐</span>') end
end
