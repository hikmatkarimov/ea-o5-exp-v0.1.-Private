package eao5.verifier;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.ECDSASigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.Curve;
import com.nimbusds.jose.jwk.ECKey;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.ECKeyGenerator;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jose.util.Base64URL;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Service-level counterparts of conformance.yaml CT1-CT7, plus the boundaries the contract relies on
 * (60 s access-token skew, issuer, htm, query handling, the external-URL rule). The stack-level tests
 * are still run through Envoy before the first run and after the last run; these tests show that the
 * deposited implementation behaves as specified before any testbed exists.
 *
 * Requests imitate what Envoy's ext_authz filter sends: original method and path, original Host,
 * X-Forwarded-Proto, Authorization and DPoP.
 */
@SpringBootTest
@AutoConfigureMockMvc
class VerifierConformanceTest {

	static final String ISSUER = "https://idp.testbed.example/realms/eao5";

	static final String AUDIENCE = "external-api";

	static final String HOST = "api.testbed.example";

	static final String PATH = "/v1/integration/calls";

	static final String HTU = "https://" + HOST + PATH;

	static final RSAKey IDP = generateRsa();

	static final ECKey KEY_A = generateEc();

	static final ECKey KEY_B = generateEc();

	@Autowired
	MockMvc mvc;

	@DynamicPropertySource
	static void properties(DynamicPropertyRegistry registry) throws Exception {
		Path jwks = Files.createTempFile("eao5-jwks", ".json");
		Files.writeString(jwks, new JWKSet(IDP.toPublicJWK()).toString());
		registry.add("eao5.verifier.jwks-path", jwks::toString);
		registry.add("eao5.verifier.issuer", () -> ISSUER);
		registry.add("eao5.verifier.audience", () -> AUDIENCE);
	}

	// ------------------------------------------------------------------ CT1-CT7

	@Test
	void ct1ValidDPoPFromAIsAllowed() throws Exception {
		String token = accessToken(KEY_A, 300, 0);
		this.mvc.perform(external(get(PATH)).header("Authorization", "DPoP " + token)
			.header("DPoP", proof(KEY_A, "GET", HTU, token))).andExpect(status().isOk());
	}

	@Test
	void ct2DPoPBoundTokenWithoutProofIsDenied() throws Exception {
		String token = accessToken(KEY_A, 300, 0);
		this.mvc.perform(external(get(PATH)).header("Authorization", "DPoP " + token))
			.andExpect(status().isUnauthorized());
	}

	@Test
	void ct3ProofSignedByBIsDenied() throws Exception {
		String token = accessToken(KEY_A, 300, 0);
		this.mvc.perform(external(get(PATH)).header("Authorization", "DPoP " + token)
			.header("DPoP", proof(KEY_B, "GET", HTU, token))).andExpect(status().isUnauthorized());
	}

	@Test
	void ct4ReplayedProofIsDenied() throws Exception {
		String token = accessToken(KEY_A, 300, 0);
		String proof = proof(KEY_A, "GET", HTU, token);
		this.mvc.perform(external(get(PATH)).header("Authorization", "DPoP " + token).header("DPoP", proof))
			.andExpect(status().isOk());
		this.mvc.perform(external(get(PATH)).header("Authorization", "DPoP " + token).header("DPoP", proof))
			.andExpect(status().isUnauthorized());
	}

	@Test
	void ct5DPoPBoundTokenAsBearerIsDenied() throws Exception {
		String token = accessToken(KEY_A, 300, 0);
		this.mvc.perform(external(get(PATH)).header("Authorization", "Bearer " + token))
			.andExpect(status().isUnauthorized());
	}

	@Test
	void ct6BearerTokenIsPortable() throws Exception {
		// Nothing in the request identifies the presenter: the same request from B is allowed.
		String token = accessToken(null, 300, 0);
		this.mvc.perform(external(post(PATH)).header("Authorization", "Bearer " + token))
			.andExpect(status().isOk());
	}

	@Test
	void ct7InternalHtuIsDenied() throws Exception {
		String token = accessToken(KEY_A, 300, 0);
		String internal = "http://dpop-verifier:9191" + PATH;
		this.mvc.perform(external(get(PATH)).header("Authorization", "DPoP " + token)
			.header("DPoP", proof(KEY_A, "GET", internal, token))).andExpect(status().isUnauthorized());
	}

	// ------------------------------------------------------------------ boundaries

	@Test
	void tokenWithinSixtySecondSkewIsStillAccepted() throws Exception {
		// exp 30 s in the past: accepted (default skew 60 s). This is why c3a cannot act before exp + 60 s.
		String token = accessToken(null, 300, -330);
		this.mvc.perform(external(get(PATH)).header("Authorization", "Bearer " + token))
			.andExpect(status().isOk());
	}

	@Test
	void tokenBeyondSkewIsDenied() throws Exception {
		String token = accessToken(null, 300, -400); // exp 100 s in the past
		this.mvc.perform(external(get(PATH)).header("Authorization", "Bearer " + token))
			.andExpect(status().isUnauthorized());
	}

	@Test
	void wrongIssuerIsDenied() throws Exception {
		String token = sign(new JWTClaimsSet.Builder().issuer("https://other.example/realms/x").audience(AUDIENCE)
			.subject("agent-a").issueTime(Date.from(Instant.now())).expirationTime(Date.from(Instant.now().plusSeconds(300)))
			.jwtID(UUID.randomUUID().toString()).build());
		this.mvc.perform(external(get(PATH)).header("Authorization", "Bearer " + token))
			.andExpect(status().isUnauthorized());
	}

	@Test
	void htmMismatchIsDenied() throws Exception {
		String token = accessToken(KEY_A, 300, 0);
		this.mvc.perform(external(post(PATH)).header("Authorization", "DPoP " + token)
			.header("DPoP", proof(KEY_A, "GET", HTU, token))).andExpect(status().isUnauthorized());
	}

	@Test
	void queryIsNotPartOfHtu() throws Exception {
		String token = accessToken(KEY_A, 300, 0);
		this.mvc.perform(external(get(PATH).queryParam("attempt", "2")).header("Authorization", "DPoP " + token)
			.header("DPoP", proof(KEY_A, "GET", HTU, token))).andExpect(status().isOk());
	}

	@Test
	void missingForwardedProtoIsDenied() throws Exception {
		String token = accessToken(null, 300, 0);
		this.mvc.perform(get(PATH).header("Host", HOST).header("Authorization", "Bearer " + token))
			.andExpect(status().isForbidden());
	}

	@Test
	void noTokenIsDenied() throws Exception {
		this.mvc.perform(external(get(PATH))).andExpect(status().isUnauthorized());
	}

	// ------------------------------------------------------------------ helpers

	static MockHttpServletRequestBuilder external(MockHttpServletRequestBuilder request) {
		return request.header("Host", HOST).header(ExternalUrlFilter.FORWARDED_PROTO, "https");
	}

	/** Access token as the IdP issues it; {@code holder == null} gives an unbound bearer token. */
	static String accessToken(ECKey holder, long lifetimeSeconds, long issuedOffsetSeconds) throws Exception {
		Instant iat = Instant.now().plusSeconds(issuedOffsetSeconds);
		JWTClaimsSet.Builder claims = new JWTClaimsSet.Builder().issuer(ISSUER)
			.audience(AUDIENCE)
			.subject("agent-a")
			.issueTime(Date.from(iat))
			.expirationTime(Date.from(iat.plusSeconds(lifetimeSeconds)))
			.jwtID(UUID.randomUUID().toString());
		if (holder != null) {
			claims.claim("cnf", Map.of("jkt", holder.computeThumbprint().toString()));
		}
		return sign(claims.build());
	}

	static String sign(JWTClaimsSet claims) throws Exception {
		SignedJWT jwt = new SignedJWT(
				new JWSHeader.Builder(JWSAlgorithm.RS256).type(JOSEObjectType.JWT).keyID(IDP.getKeyID()).build(), claims);
		jwt.sign(new RSASSASigner(IDP));
		return jwt.serialize();
	}

	static String proof(ECKey key, String htm, String htu, String accessToken) throws Exception {
		byte[] hash = MessageDigest.getInstance("SHA-256").digest(accessToken.getBytes(StandardCharsets.US_ASCII));
		JWTClaimsSet claims = new JWTClaimsSet.Builder().claim("htm", htm)
			.claim("htu", htu)
			.issueTime(Date.from(Instant.now()))
			.jwtID(UUID.randomUUID().toString())
			.claim("ath", Base64URL.encode(hash).toString())
			.build();
		SignedJWT jwt = new SignedJWT(new JWSHeader.Builder(JWSAlgorithm.ES256).type(new JOSEObjectType("dpop+jwt"))
			.jwk(key.toPublicJWK())
			.build(), claims);
		jwt.sign(new ECDSASigner(key));
		return jwt.serialize();
	}

	static RSAKey generateRsa() {
		try {
			return new RSAKeyGenerator(2048).keyID("idp-test").generate();
		}
		catch (Exception ex) {
			throw new IllegalStateException(ex);
		}
	}

	static ECKey generateEc() {
		try {
			return new ECKeyGenerator(Curve.P_256).generate();
		}
		catch (Exception ex) {
			throw new IllegalStateException(ex);
		}
	}

}
