package eao5.verifier;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;

import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.nimbusds.jose.proc.SecurityContext;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.jwt.JwtAudienceValidator;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtIssuerValidator;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * One filter chain for both arms.
 *
 * <ul>
 * <li>{@code Authorization: Bearer} (primary arm): BearerTokenAuthenticationFilter validates the JWT
 * and rejects a DPoP-bound token (one with {@code cnf.jkt}) sent this way
 * (BearerTokenAuthenticationFilter.java:181-186).</li>
 * <li>{@code Authorization: DPoP} plus a {@code DPoP} header (control arm): DPoPAuthenticationProvider
 * validates the JWT, then the proof: typ, signature, htm, htu, iat (30 s), cnf.jkt, ath and jti replay
 * (DPoPProofJwtDecoderFactory.java:76, 119, 154-161, 181-198; DPoPProofReplayValidator.java:136).</li>
 * </ul>
 *
 * <p>DPoP support must be enabled explicitly ({@code dPoP(...)}, OAuth2ResourceServerConfigurer.java:285).
 * Access tokens are checked against a JWK Set loaded once from a local file: no JWKS fetch, no
 * introspection and no revocation lookup at run time. Validators: typ JWT, exp/nbf with the default
 * 60 s clock skew (JwtTimestampValidator.java:54), issuer and audience.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.authorizeHttpRequests((authorize) -> authorize.anyRequest().authenticated())
			.csrf((csrf) -> csrf.disable())
			.sessionManagement((session) -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
			.oauth2ResourceServer((resourceServer) -> resourceServer.jwt(Customizer.withDefaults())
				.dPoP(Customizer.withDefaults()));
		return http.build();
	}

	@Bean
	JwtDecoder jwtDecoder(VerifierProperties properties) throws IOException, ParseException {
		JWKSet jwkSet = JWKSet.load(new File(properties.jwksPath()));
		NimbusJwtDecoder decoder = NimbusJwtDecoder.withJwkSource(new ImmutableJWKSet<SecurityContext>(jwkSet))
			.build();
		decoder.setJwtValidator(JwtValidators.createDefaultWithValidators(
				new JwtIssuerValidator(properties.issuer()), new JwtAudienceValidator(properties.audience())));
		return decoder;
	}

}
