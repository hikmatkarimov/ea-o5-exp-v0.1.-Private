package eao5.verifier;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Testbed values, set at deployment and captured by the hashed realm export and Envoy config.
 *
 * @param jwksPath local file holding the realm's public JWK Set (exported once at setup; never fetched at run time)
 * @param issuer expected {@code iss} of access tokens (the Keycloak realm URL)
 * @param audience expected {@code aud} of access tokens (the same value Envoy's jwt_authn checks)
 */
@ConfigurationProperties(prefix = "eao5.verifier")
public record VerifierProperties(String jwksPath, String issuer, String audience) {
}
