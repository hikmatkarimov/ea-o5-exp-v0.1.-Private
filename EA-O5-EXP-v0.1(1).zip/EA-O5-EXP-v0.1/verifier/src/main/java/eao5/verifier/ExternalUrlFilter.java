package eao5.verifier;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Frozen htu rule (sources.yaml, dpop_enforcement.htu_rule).
 *
 * <p>Spring Security compares the proof's {@code htu} with {@code request.getRequestURL()}
 * (DPoPAuthenticationConverter.java:84). Behind ext_authz that would be the verifier's own URL, so
 * this filter, which runs before the security filter chain, rebuilds the external request target
 * from what Envoy forwards:
 *
 * <pre>htu = X-Forwarded-Proto + "://" + Host + path</pre>
 *
 * <p>Envoy always forwards the original Host, method and path to an HTTP authorization server
 * (ext_authz.proto:237-238); X-Forwarded-Proto and DPoP are added through allowed_headers, and the
 * http_service has an empty path_prefix. {@code getRequestURI()} excludes the query, and HTTP
 * requests carry no fragment, so the result has neither (RFC 9449 section 4.3). A request without
 * exactly one X-Forwarded-Proto of "http" or "https", or without exactly one Host, is denied with 403.
 */
@Component
public class ExternalUrlFilter extends OncePerRequestFilter implements Ordered {

	static final String FORWARDED_PROTO = "X-Forwarded-Proto";

	@Override
	public int getOrder() {
		return Ordered.HIGHEST_PRECEDENCE;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {
		List<String> protos = Collections.list(request.getHeaders(FORWARDED_PROTO));
		List<String> hosts = Collections.list(request.getHeaders("Host"));
		if (protos.size() != 1 || hosts.size() != 1) {
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			return;
		}
		String proto = protos.get(0);
		String host = hosts.get(0);
		if (!("https".equals(proto) || "http".equals(proto)) || host.isEmpty() || host.contains(",")) {
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			return;
		}
		String externalUrl = proto + "://" + host + request.getRequestURI();
		chain.doFilter(new ExternalUrlRequest(request, proto, externalUrl), response);
	}

	private static final class ExternalUrlRequest extends HttpServletRequestWrapper {

		private final String scheme;

		private final String url;

		ExternalUrlRequest(HttpServletRequest request, String scheme, String url) {
			super(request);
			this.scheme = scheme;
			this.url = url;
		}

		@Override
		public StringBuffer getRequestURL() {
			return new StringBuffer(this.url);
		}

		@Override
		public String getScheme() {
			return this.scheme;
		}

		@Override
		public boolean isSecure() {
			return "https".equals(this.scheme);
		}

	}

}
