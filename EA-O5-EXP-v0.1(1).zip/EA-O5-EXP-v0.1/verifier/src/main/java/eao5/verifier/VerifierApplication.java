package eao5.verifier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * EA-O5-EXP-v0.1 DPoP verifier.
 *
 * <p>Envoy 1.38.5 calls this service through its ext_authz HTTP filter for every request to the
 * external API, in both arms. A 200 response lets Envoy forward the request; any other status is
 * returned to the caller as the denial. The service makes no outbound call: access tokens are
 * validated against a local JWKS file, with no token introspection and no revocation lookup.
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class VerifierApplication {

	public static void main(String[] args) {
		SpringApplication.run(VerifierApplication.class, args);
	}

}
