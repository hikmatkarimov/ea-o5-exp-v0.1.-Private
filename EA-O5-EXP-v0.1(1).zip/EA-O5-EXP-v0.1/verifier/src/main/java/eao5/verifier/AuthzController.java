package eao5.verifier;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Reached only when the security filter chain has authenticated the request: answers 200 for any
 * path and method, which Envoy's ext_authz filter reads as "allow". Envoy sends the original method
 * and path (no path prefix), so the proof's htm and htu are checked against the real request.
 */
@RestController
public class AuthzController {

	@RequestMapping("/**")
	ResponseEntity<Void> allow() {
		return ResponseEntity.ok().build();
	}

}
